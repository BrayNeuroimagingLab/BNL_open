## PURPOSE: making overlapping CI for pretermsexint betas for subcortical regions

# libraries
library(tidyverse)
library(fsbrain)
library(readxl)

measures <- c("subcortical", "cerebellar", "ventricular")


# regions
aseg_subcortical_names <- read_xlsx("/Users/niloynath/OneDrive - ualberta.ca/bray lab stuff/ABCD_paper_revisions/aseg_subcortical_names.xlsx") # contains shorter version of region names
subcortical_regions_name <- aseg_subcortical_names$subcortical_regions_new
cerebellar_regions_name <- aseg_subcortical_names$cerebellar_regions_new[which(!is.na(aseg_subcortical_names$cerebellar_regions_new))]
ventricular_regions_name <- aseg_subcortical_names$ventricular_regions_new[which(!is.na(aseg_subcortical_names$ventricular_regions_new))]


# full group analyses figures

for (i in 1:length(measures)) {
  beta <- read_csv(sprintf("/Users/niloynath/OneDrive - ualberta.ca/bray lab stuff/ABCD_paper_revisions/results/fixing_preterm_group_seven_original_analysis/%s/pretermsexint/beta_pretermsexint_%s_controlled_liberal.csv",
                           measures[i], measures[i]))
  
  if  (measures[i] == "ventricular") {
    beta <- beta[1:length(ventricular_regions_name), ]
  }
  
  # need to create an if_statement for subcortical region names based on which measures
  if (measures[i] == "subcortical") {
    beta$regions <- subcortical_regions_name
  } else if (measures[i] == "cerebellar") {
    beta$regions <- cerebellar_regions_name
  } else {
    beta$regions <- ventricular_regions_name
  }
  
  # create boundaries of the ggplot so that plot is centred on zero
  limit <- max(c(abs(min(beta$lower_99CI)), abs(max(beta$upper_99CI))))
  
  beta_base <- ggplot(beta, aes(x = reorder(regions, beta_coefficient),
                                y = beta_coefficient))
  beta_base + 
    geom_point() +
    geom_errorbar(aes(y = beta_coefficient, ymin = lower_99CI, ymax = upper_99CI)) +
    geom_abline(slope = 0, intercept = 0) +
    coord_flip() +
    xlab("") +
    ylab("Standardized beta estimate (a.u.)") +
    theme(panel.grid.major = element_blank(),
          panel.grid.minor = element_blank(),
          panel.background = element_blank(),
          axis.line = element_line(colour = "black")) +
    scale_y_continuous(limits =  c(-(limit),limit))
  
  # save
  save_directory <- "/Users/niloynath/OneDrive - ualberta.ca/bray lab stuff/ABCD_paper_revisions/figures/pretermsexint_overlappingCI/"
  save_file <- sprintf("ABCD_%s_pretermsexint_overlappingCI.png",
                       measures[i])
  ggsave(paste0(save_directory, save_file),
         dpi = 300)
}
