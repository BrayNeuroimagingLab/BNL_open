## PURPOSE: making overlapping CI of the pretermsexint betas for cortical regions

# libraries
library(tidyverse)
library(fsbrain)
library(readxl)

# hemi - LH, RH
hemi <- c("LH", "RH")

# measures - CT, SA
measures <- c("CT", "SA")

# contains shorter version of region names
regions_name <- read_xlsx("/Users/niloynath/OneDrive - ualberta.ca/bray lab stuff/ABCD_paper_revisions/destrieux_region_names.xlsx") 

# full group analyses figures
for (i in 1:length(measures)) {
  lh_values <- read_csv(sprintf("/Users/niloynath/OneDrive - ualberta.ca/bray lab stuff/ABCD_paper_revisions/results/fixing_preterm_group_seven_original_analysis/%s_%s/pretermsexint/beta_pretermsexint_%s_%s_controlled_liberal.csv",
                                hemi[1], measures[i], hemi[1], measures[i]))
  rh_values <- read_csv(sprintf("/Users/niloynath/OneDrive - ualberta.ca/bray lab stuff/ABCD_paper_revisions/results/fixing_preterm_group_seven_original_analysis/%s_%s/pretermsexint/beta_pretermsexint_%s_%s_controlled_liberal.csv",
                                hemi[2], measures[i], hemi[2], measures[i]))
  
  ################################
  # 99% overlapping stacked CI
  
  # upload necessary data
  LHCT_beta <- lh_values
  RHCT_beta <- rh_values
  
  # replace region names with shorter versions
  LHCT_beta$regions <- regions_name$destriuex_region_actual_name
  RHCT_beta$regions <- regions_name$destriuex_region_actual_name
  
  # create boundaries of the ggplot so that plot is centred on zero
  limit <- max(c(abs(min(LHCT_beta$lower_99CI)), abs(max(LHCT_beta$upper_99CI))))
  
  # create LHCT overlapping CI (upper and lower bounds of 99% CI)
  LHCT_beta_base <- ggplot(LHCT_beta, aes(x = reorder(regions, beta_coefficient),
                                          y = beta_coefficient))
  LHCT_beta_base + 
    geom_point() +
    geom_errorbar(aes(y = beta_coefficient, ymin = lower_99CI, ymax = upper_99CI)) +
    geom_abline(slope = 0, intercept = 0) +
    coord_flip() + 
    xlab("") +
    ylab("Standardized beta estimate (a.u.)") +
    theme(panel.grid.major = element_blank(),
          panel.grid.minor = element_blank(),
          panel.background = element_blank(),
          axis.line = element_line(colour = "black")) +
    scale_y_continuous(limits =  c(-(limit),limit))
  
  # save
  save_directory <- "/Users/niloynath/OneDrive - ualberta.ca/bray lab stuff/ABCD_paper_revisions/figures/pretermsexint_overlappingCI/"
  save_file <- sprintf("ABCD_LH%s_pretermsexint_overlappingCI.png",
                       measures[i])
  ggsave(paste0(save_directory, save_file),
         height = 10,
         dpi = 300)
  
  # create boundaries of the ggplot so that plot is centred on zero
  limit <- max(c(abs(min(RHCT_beta$lower_99CI)), abs(max(RHCT_beta$upper_99CI))))
  
  # create RHCT overlapping CI (upper and lower bounds of 99% CI)
  RHCT_beta_base <- ggplot(RHCT_beta, aes(x = reorder(regions, beta_coefficient),
                                          y = beta_coefficient))
  RHCT_beta_base + 
    geom_point() +
    geom_errorbar(aes(y = beta_coefficient, ymin = lower_99CI, ymax = upper_99CI)) +
    geom_abline(slope = 0, intercept = 0) +
    coord_flip() + 
    xlab("") +
    ylab("Standardized beta estimate (a.u.)") +
    theme(panel.grid.major = element_blank(),
          panel.grid.minor = element_blank(),
          panel.background = element_blank(),
          axis.line = element_line(colour = "black")) +
    scale_y_continuous(limits =  c(-(limit),limit))
  
  # save
  save_directory <- "/Users/niloynath/OneDrive - ualberta.ca/bray lab stuff/ABCD_paper_revisions/figures/pretermsexint_overlappingCI/"
  save_file <- sprintf("ABCD_RH%s_pretermsexint_overlappingCI.png",
                       measures[i])
  ggsave(paste0(save_directory, save_file),
         height = 10,
         dpi = 300)
    

}